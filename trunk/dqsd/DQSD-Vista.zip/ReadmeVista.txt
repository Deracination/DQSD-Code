/***********************************************************
* Readme File for updating DQSD look and feel on Windows
* Vista. This document, and the files it describes, are
* provided as is, with no warrantee expressed or implied. 
* But hey, it worked for me, and it looks a lot better than
* it did before!
*
* Version 1.0, created 28 December, 2006 by Charlie Russel
* ModHist: 
* 
*/

The default colour schemes shipped with DQSD are designed to look 
right on Windows XP. But Windows Vista has an all new look and feel
and the colours for DQSD just don't look good on Windows Vista.
Actually, if you've installed DQSD on Vista, you'll already know
that they're just plain butt ugly. 

The included files here will fix that. They're not perfect, but they're 
a whole lot better than the defaults. I did the first pass at fixing
this colour problem, and then got some great help from Matt. The
result is what you see in this group of files. There should be five
files here. This readme, plus:
   Vistatoolbar1_vista.bmp
   Vistatoolbar2_vista.bmp
   Theme_vista.css
   DQSD.png

The file that does all the heavy lifting is Theme_Vista.css. It is the
file that describes the theme for DQSD and sets all the colours and stuff.
However, unlike with Windows XP, with Windows Vista you can't easily change 
themes on the fly - User Account Contro (UAC) gets in the way. What
you need to do is first save off your existing Theme.css file to 
something that won't get overwritten.

Next, copy the 5 files here to your default DQSD installation directory. 
(Normally, C:\Program Files\Quick Search Deskbar.) Now, replace your 
exisiting Theme.css with the Theme_Vista.css file by deleting Theme.css 
and renaming Theme_vista.css to Theme.css. 

Once you've done that, simply reload DQSD using the ! command. Or 
click on the chevron (">>") and select Configure from the menu. 

That should be sufficient. But if it still doesn't look quite right, 
just reboot and it should be fine. Enjoy. 

Charlie. 
