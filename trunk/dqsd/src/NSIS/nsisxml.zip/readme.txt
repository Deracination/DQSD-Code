nsisXML plugin to create and parse XML files using MSXML 2.6 (hope Win98 and better have it)

Instructions:
- Copy nsisXML.dll to Plugins and nsisXML.nsh to include directories
- Read this readme and example files.

Functions:

==[Build]==

Displays the build version of the plugin.
Example: ${nsisXML->Build} ${VAR_RET}

==[xPath]==

Uses xPath syntax to parse and get strings from elements or attributes values.
Example: ${nsisXML->xPath} "PATH_OF_XML_FILE" "XPATH_INSTRUCTION" ${VAR_RET}

==[Create]==

Creates, in memory, the template of the xml file.
Example: ${nsisXML->Create}

==[CreateElement]==

Let's you create a xml element, from the parent document or from another node. Note: use "XPATH_INSTRUCTION" to locate a node where to put the new element; empty param means the element will be the first child; also "DO_TAB" will make a "tidy" element, use "1" as param to make it, other wise empty means the element will not have tidy (see example #2).
Example: ${nsisXML->CreateElement} "XPATH_INSTRUCTION" "STRING_ELEMENT" "DO_TAB"

==[CreateComment]==

Creates a comment after an element.
Example: ${nsisXML->CreateComment} "XPATH_INSTRUCTION" "STRING_COMMENT"

==[SetElementAttr]==

Adds an attribute and its value to an element.
Example: ${nsisXML->SetElementAttr} "XPATH_INSTRUCTION" "Attribute" "Value"

==[SetElementText]==

Sets the text for an element.
Example: ${nsisXML->SetElementText} "XPATH_INSTRUCTION" "STRING_TEXT"

==[Display]==

Shows in a MessageBox How's your xml tree going.
Example: ${nsisXML->Display}

==[Release]==

Frees the memory from the xml template and save the xml into a file.
Example: ${nsisXML->Release} "PATH_OF_XML_FILE"

==[OpenXML]==

Opens a xml file.
Example: ${nsisXML->OpenXML} "PATH_OF_XML_FILE"

==[LoadXML]==

Loads a xml string tree
Example: ${nsisXML->LoadXML} "PATH_OF_THE_FUTURE_XML_FILE" "XML_STRING_TREE"

==[CloseXML]==

Closes 'OpenXML' or 'LoadXML' functions and saves the updates made to the file.
Example: ${nsisXML->CloseXML}

==[xml]==

Dump in a output var, the xml tree.
Example: ${nsisXML->xml} ${VAR_RET}

==[removeChild]==

Remove an element, upon of the selected index of the node that have it.
Example: ${nsisXML->removeChild} "XPATH_INSTRUCTION" "index_of_the_child_to_remove"

==[removeAttr]==

Remove an attribute, upon of the selected name.
Example: ${nsisXML->removeChild} "XPATH_INSTRUCTION" "name_of_the_attribute_to_remove"

==[TidyFile]==

Makes the XML string from a <file> cuter :), see example #9.
Example: ${nsisXML->TestFile}

==[TestBegin]==

Creates a template of XML in the memory, no need params and they are just for testing tasks (see example #8).
Example: ${nsisXML->TestBegin}

==[TestXML]==

Loads a xml string to test your xpath syntaxes.
Example: ${nsisXML->TestXML}

==[TestFile]==

Loads a xml file to test your xpath syntaxes.
Example: ${nsisXML->TestFile}

==[TestShow]==

Shows in a MessageBox the current XML tree.
Example: ${nsisXML->TestShow}

==[TestEnd]==

Cleans the xml template from the memory.
Example: ${nsisXML->TestEnd}